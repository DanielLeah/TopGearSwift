import UIKit
// Exercise 1

//func input() -> String {
//    let keyboard = FileHandle.standardInput
//    let inputData = keyboard.availableData
//    return String(data: inputData, encoding: .utf8)!
//}
//
//print("Please enter a character")
//var character = input()
//print("Please enter a Number")
//if let number = Int( input()){
//    var i = 0;
//    while i<number {
//        print(character)
//        i += 1
//    }
//}

//Exercise 2

//func swap(var1 : inout Any, var2: inout Any){
//    let var3 = var1
//    var1 = var2
//    var2 = var3
//}
//
//var variable1 = "Something"
//var variable2 = "New"
//swap(&variable1, &variable2)
//print("First variable changed:\(variable1) and second variable changed: \(variable2)")

//Exercise 3
/*
func binarySearch<T:Comparable>(inputArr:Array<T>, searchItem: T) -> Int? {
    var lowerIndex = 0;
    var upperIndex = inputArr.count - 1

    while (true) {
        let currentIndex = (lowerIndex + upperIndex)/2
        if(inputArr[currentIndex] == searchItem) {
            return currentIndex
        } else if (lowerIndex > upperIndex) {
            return nil
        } else {
            if (inputArr[currentIndex] > searchItem) {
                upperIndex = currentIndex - 1
            } else {
                lowerIndex = currentIndex + 1
            }
        }
    }
}

var myArray = [1,2,3,4,5,6,7,9,10];
if let searchIndex = binarySearch(inputArr: myArray,searchItem: 5){
    print("Element found on index: \(searchIndex)");
}
*/
//Exercise 4
/*
func flexString(param1: String? = nil, param2: String? = nil, param3: String? = nil) -> String{
    var finalString = ""
    if let p1 = param1{
        finalString += p1
        if let p2 = param2 {
            finalString += p2
            if let p3 = param3{
                finalString += p3
            }
        }
    }
    if finalString == "" {
        return "none"
    }else {
        return finalString
    }
}
print(flexString())
*/
//Exercise 5
/*
func sumAny(elements: Any...) -> String {
    var sum = 0
    for element in elements{
        if (element as? String == "" || element as? Int == 0){
            sum -= 10
        }else if let stringNo = element as? String{
            if let intNo = Int(stringNo){
                if intNo > 0 {
                    sum += intNo
                }
            }
        }else if let intNo = element as? Int {
            sum += intNo
        }
    }
    return String(sum)
}
print(sumAny(elements:"3", 2, 3, 3, "DASD", ""))
*/
//Exercise 6

/*
class Shape {
    func area() -> Float {
        return 0
    }
    func perimeter() -> Float{
        return 0
    }
}
class Circle: Shape {
    let radius = 0
}
class Square: Shape {
    let length = 0
}
class Rectangle: Shape {
    let length = 0
    let width = 0
}

protocol Shape {
    func area() -> Float
    func perimeter() -> Float
}
class Circle: Shape {
    var radius = 0
    init(radius : Int) {
        self.radius = radius
    }
    func area() -> Float {
        return Float(radius * radius) * .pi
    }
    func perimeter() -> Float {
        return Float(2 * radius) * .pi
    }
}
class Square: Shape {
    var length = 0
    init(length : Int) {
        self.length = length
    }
    func area() -> Float {
        return Float(length * length)
    }
    func perimeter() -> Float {
        return Float(4 * length)
    }
}
class Rectangle: Shape {
    var length = 0
    var width = 0
    init(length : Int, width: Int) {
        self.length = length
        self.width = width
    }
    func area() -> Float {
        return Float(length * width)
    }
    func perimeter() -> Float {
        return Float(2 * (length + width))
    }
}

let circle1 = Circle(radius: 2)
let circle2 = Circle(radius: 4)
print("Circle1 area is: \(circle1.area()) and perimeter is: \(circle1.perimeter())")

let square1 = Square(length: 2)
let square2 = Square(length: 4)
print("Square1 area is: \(square1.area()) and perimeter is: \(square1.perimeter())")

let rectangle1 = Rectangle(length: 2, width: 3)
let rectangle2 = Rectangle(length: 2, width: 13)
print("rectangle1 area is: \(rectangle1.area()) and perimeter is: \(rectangle1.perimeter())")

var shapes = []
shapes.append(square1)
shapes.append(square2)
var totalArea = 0;
var totalPerimeter = 0;
for shape in shapes {
    totalArea += shape.area()
    totalPerimeter += shape.perimeter()
}
*/

//Exercise 7

func printCommonElements(listOfNumbers: [Int], otherNumbers: [Int]) -> [Int]{
    var finalArray : [Int] = []
    for element in otherNumbers {
        if listOfNumbers.contains(element) {
            finalArray.append(element)
        }
    }
    return finalArray
}

if printCommonElements(listOfNumbers: [1,21,13,10,100], otherNumbers: [1,2,3,4,5,6]).count > 0{
    print(printCommonElements(listOfNumbers: [1,21,13,10,100], otherNumbers: [1,2,3,4,5,6]))
}
