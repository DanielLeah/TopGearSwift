import UIKit

//Exercise 5
//Write a function called sumAny that can take 0 or more parameters of any type. The function should meet the following requirements:

//•    The function will return the sum of the passed parameters as a String, following the rules below.
//•    If a parameter is an empty string or an Int equal to 0, add -10 to the result.
//•    If a parameter is a String that represents a positive number (e.g. “10”, not “-5”), add it to the result.
//•    If a parameter is an Int, add it to the result.
//•    In any other case, do not add it to the result.

func sumAny(elements: Any...) -> String {
    var sum = 0
    for element in elements{
        if (element as? String == "" || element as? Int == 0){
            sum -= 10
        }else if let stringNo = element as? String{
            if let intNo = Int(stringNo){
                if intNo > 0 {
                    sum += intNo
                }
            }
        }else if let intNo = element as? Int {
            sum += intNo
        }
    }
    return String(sum)
}
print(sumAny(elements:"3", 2, 3, 3, "DD", ""))

