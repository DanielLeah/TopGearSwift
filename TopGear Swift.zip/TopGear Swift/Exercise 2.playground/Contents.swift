import UIKit

//Exercise 2
//Write a function that takes two variables (of any type) as parameters and swaps their values.

func swap(var1 : inout Any, var2: inout Any){
    let var3 = var1
    var1 = var2
    var2 = var3
}

var variable1 = "Something"
var variable2 = "New"
swap(&variable1, &variable2)
print("First variable changed:\(variable1) and second variable changed: \(variable2)")
