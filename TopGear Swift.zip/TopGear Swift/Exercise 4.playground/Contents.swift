import UIKit
//Exercise 4
//Write a function called flexStrings that meets the following requirements:

//•    The function can take precisely 0, 1 or 2 string parameters.
//•    Returns the function parameters concatenated as String.
//•    If no parameters pass to the function, it will return the string “none”.




 func flexString(param1: String? = nil, param2: String? = nil, param3: String? = nil) -> String{
    var finalString = ""
    if let p1 = param1{
        finalString += p1
        if let p2 = param2 {
            finalString += p2
            if let p3 = param3{
                finalString += p3
            }
        }
    }
    if finalString == "" {
        return "none"
    }else {
        return finalString
    }
 }
 print(flexString())

