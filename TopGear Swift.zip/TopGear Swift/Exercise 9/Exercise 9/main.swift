//
//  main.swift
//  Exercise 9
//
//  Created by David Daniel Leah (BFS EUROPE) on 25/07/2019.
//  Copyright © 2019 David Daniel Leah (BFS EUROPE). All rights reserved.
//

import Foundation

//Exercise 9

/*Create a program that allows a user to do the following:
 
 1)    Create a bank account by supplying a user id and password.
 2)    Login using their id and password.
 3)    Quit the program.
 
 Now if login was successful the user will be able to do the following:
 
 •    Withdraw money.
 2)    Deposit money.
 3)    Request balance.
 4)    Quit the program.
 
 If login was not successful (for example the id or password did not match) then the user will be taken back to the introduction menu.
 
 This is what your program in action will look like:
 
 Hi! Welcome to Mr. Zamar’s ATM Machine!
 
 Please select an option from the menu below:
 
 l  -> Login
 c -> Create New Account
 q -> Quit
 
 > l
 
 Please enter your user id: 12
 Please enter your password 2345
 
 ******** LOGIN FAILED! ********
 
 Please select an option from the menu below:
 
 l  -> Login
 c -> Create New Account
 q -> Quit
 
 > c
 
 Please enter your user name: 12
 Please enter your password: 2345
 
 Thank You! Your account has been created!
 
 l  -> Login
 c -> Create New Account
 q -> Quit
 
 > l
 
 Please enter your user id: 12
 Please enter your password: 2345
 
 Access Granted!
 
 d -> Deposit Money
 w -> Withdraw Money
 r  -> Request Balance
 
 > d
 
 Amount of deposit: $20
 
 d -> Deposit Money
 w -> Withdraw Money
 r  -> Request Balance
 
 > r
 
 Your balance is $20.
 
 d -> Deposit Money
 w -> Withdraw Money
 r  -> Request Balance
 
 > w
 
 Amount of withdrawal: $2.5
 
 d -> Deposit Money
 w -> Withdraw Money
 r  -> Request Balance
 
 > r
 
 Your balance is $17.5.
 
 d -> Deposit Money
 w -> Withdraw Money
 r  -> Request Balance
 
 > q
 */

class User {
    var id : String
    var password : String
    var balance : Double
    
    init(id: String, password: String) {
        self.id = id
        self.password = password
        self.balance = 0
    }
}

var users : [User] = []

func input() -> String {
    let keyboard = FileHandle.standardInput
    let inputData = keyboard.availableData
    return String(data: inputData, encoding: .utf8)!
}

//Main func

func runMachine(){
    
    var character = ""
    while character != "q" {
        print("HI! Welcom to Mr.Zamar's ATM Machine! \n\nPlease select an option from the menu below:\nl -> Login \nc -> Create New Account \nq -> Quit")
        character = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
        if character == "l"{
            
            if let user = loginUser() {
                print("\nAccess granted!\n")
                while character != "q" {
                    print("\nd -> Deposit money \nw -> Withdraw money \nr -> Request balance")
                    character = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
                    if character == "d"{
                        updateBalance(type: character,user: user)
                    }else if character == "w"{
                        updateBalance(type: character,user: user)
                    }else if character == "r"{
                        print("Your balnce is: \(user.balance)")
                    }
                }
            }else{
                print("*****LOGIN FAILED*****")
            }
            
        }else if character == "c" {
            //create account
            users.append(createUser())
            
            print("\n\n Thank you! Your account has been created!")
        }
    }
    print("Thanks for stopping by!")
}

//create account
func createUser() -> User{
    print("Please enter your user id : ")
    let userID = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
    print("Please enter your password : ")
    let userPassword = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
    let user = User(id: userID, password: userPassword)
    return user
}

func loginUser() -> User? {
    print("Please enter your user id : ")
    let userID = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
    print("Please enter your password : ")
    let userPassword = input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil)
    
    for user in users {
        if userID == user.id && userPassword == user.password {
            return user
        }
    }
    return nil
}

//Update Balance

func updateBalance(type: String, user: User){
    let indexOfUser = users.firstIndex(where: {$0.id == user.id})
    if type == "d"{
        print("\nAmount of deposit: ")
        let amount = Double(input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil))
        user.balance = user.balance + amount!
    }else if type == "w"{
        print("\nAmount of withdrawal: ")
        let amount = Double(input().replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range:nil))
        user.balance = user.balance - amount!
    }
    users[indexOfUser!] = user
}


runMachine()
