import UIKit
//Exercise 7
/*Print all the elements from otherNumbers that appear in listOfNumbers. Don’t print anything if listOfNumbers andotherNumbers have no common elements.
var listOfNumbers = [1, 2, 3, 10, 100]
var otherNumbers = [1, 2, 3, 4, 5, 6]*/


func printCommonElements(listOfNumbers: [Int], otherNumbers: [Int]) -> [Int]{
    var finalArray : [Int] = []
    for element in otherNumbers {
        if listOfNumbers.contains(element) {
            finalArray.append(element)
        }
    }
    return finalArray
}

if printCommonElements(listOfNumbers: [1,21,13,10,100], otherNumbers: [1,2,3,4,5,6]).count > 0{
    print(printCommonElements(listOfNumbers: [1,21,13,10,100], otherNumbers: [1,2,3,4,5,6]))
}
