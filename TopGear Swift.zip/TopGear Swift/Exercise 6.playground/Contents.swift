import UIKit
//
//Exercise 6
//Create a Shape base class and derive from it Circle, Square and Rectangle. Shape should have two methods area() -> Float and perimeter() -> Float that both return 0. Implement the methods and add the necessary properties on Circle, Square and Rectangle.


class Shape {
    func area() -> Float {
        return 0
    }
    func perimeter() -> Float{
        return 0
    }
}
class Circle: Shape {
    let radius = 0
}
class Square: Shape {
    let length = 0
}
class Rectangle: Shape {
    let length = 0
    let width = 0
}

//6.1    create the same classes from the first exercise, but this time make Shape a protocol

//protocol Shape {
//    func area() -> Float
//    func perimeter() -> Float
//}


//6.2    create a custom initializer for Circle, Square and Rectangle and create two instance of each one
//class Circle: Shape {
//    var radius = 0
//    init(radius : Int) {
//        self.radius = radius
//    }
//    func area() -> Float {
//        return Float(radius * radius) * .pi
//    }
//    func perimeter() -> Float {
//        return Float(2 * radius) * .pi
//    }
//}
//class Square: Shape {
//    var length = 0
//    init(length : Int) {
//        self.length = length
//    }
//    func area() -> Float {
//        return Float(length * length)
//    }
//    func perimeter() -> Float {
//        return Float(4 * length)
//    }
//}

//class Rectangle: Shape {
//    var length = 0
//    var width = 0
//    init(length : Int, width: Int) {
//        self.length = length
//        self.width = width
//    }
//    func area() -> Float {
//        return Float(length * width)
//    }
//    func perimeter() -> Float {
//        return Float(2 * (length + width))
//    }
//}

//let circle1 = Circle(radius: 2)
//let circle2 = Circle(radius: 4)
//print("Circle1 area is: \(circle1.area()) and perimeter is: \(circle1.perimeter())")
//
//let square1 = Square(length: 2)
//let square2 = Square(length: 4)
//print("Square1 area is: \(square1.area()) and perimeter is: \(square1.perimeter())")
//
//let rectangle1 = Rectangle(length: 2, width: 3)
//let rectangle2 = Rectangle(length: 2, width: 13)
//print("rectangle1 area is: \(rectangle1.area()) and perimeter is: \(rectangle1.perimeter())")



//6.3    add the instance created in the exercise above into an array shapes and use polymorphism to find out the total area and perimeter of the shapes

//var shapes = []
//shapes.append(square1)
//shapes.append(square2)
//var totalArea = 0;
//var totalPerimeter = 0;
//for shape in shapes {
//    totalArea += shape.area()
//    totalPerimeter += shape.perimeter()
//}

