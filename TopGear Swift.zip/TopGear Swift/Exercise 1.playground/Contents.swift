import UIKit

// Exercise 1
//Overload the “*” operator so it takes a Character and an Int and produces a String with the character repeated Int times.

func input() -> String {
    let keyboard = FileHandle.standardInput
    let inputData = keyboard.availableData
    return String(data: inputData, encoding: .utf8)!
}

print("Please enter a character")
var character = input()
print("Please enter a Number")
if let number = Int( input()){
    var i = 0;
    while i<number {
        print(character)
        i += 1
    }
}
