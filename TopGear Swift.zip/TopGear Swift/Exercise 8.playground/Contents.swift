import UIKit

//Exercise 8
/* Mario uses energy points to walk and jump. He can jump maximum maxJump meters up or down. You have the height of each 1 meter portion of a level in the heights array. Determine if Mario can finish the level and how much energy he needs to do it. Mario uses 1 energy point to walk one meter and 2 * jumpHeight energy points to jumpHeightmeters. Write a function named levelCost that takes heights and maxJump as parameters and returns -1 if Mario cannot finish the level or the total energy cost that he would need to finish the level.

 In the beginning Mario will be on the first 1 meter section of the level and the heights array will always have more than one element. All heights have a value greater or equal to 1.
 
 Reference:
 
 levelCost(heights: [1, 1, 2, 2, 5, 2, 1, 1], maxJump: 3) // 19
 // 1 point to walk
 // 2 to jump from 1 to 2
 // 1 point to walk
 // 6 to jump from 2 to 5
 // 6 to jump from 5 to 2
 // 2 to jump from 2 to 1
 // 1 point to walk
 
 levelCost(heights: [1, 1, 3, 1, 1], maxJump: 2) // 10
 // 1 point to walk
 // 4 to jump from 1 to 3
 // 4 to jump from 3 to 1
 // 1 point to walk
 
 levelCost(heights: [1, 1, 8, 1], maxJump: 5) // -1
  Mario cannot jump from 1 to 8 */

func levelCost(heights: [Int], maxJump: Int) -> Int {
    var cost = 0
    var index = 1
    while index < heights.count{
        if (abs(heights[index]-heights[index - 1]) <= maxJump){
            if heights[index] == heights[index - 1] {
                cost += 1
            }else{
                cost += 2 * abs(heights[index]-heights[index - 1])
            }
            
        } else {
            return -1
        }
        index += 1
    }
    return cost
}

print(levelCost(heights: [1,1,2,2,5,2,1,1], maxJump: 3))
